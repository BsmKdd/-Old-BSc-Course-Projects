<?php
	$servername="localhost";
	$username="id12779750_mygym";
	$password="JounaidSaadi@1";
	$db="id12779750_mygymdb";

	$con = mysqli_connect($servername,$username,$password,$db);
?>